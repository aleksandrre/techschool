// import mongoose from "mongoose";
// const resourceSchema = new mongoose.Schema({
//   username: {
//     type: String,
//     required: true,
//   },

//   group: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "Group",
//     required: true,
//   },
// });

// export const Resource = mongoose.model("resource", resourceSchema);
